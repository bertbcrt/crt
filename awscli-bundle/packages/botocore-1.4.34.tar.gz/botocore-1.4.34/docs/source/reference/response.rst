.. _ref-response:

==================
Response Reference
==================

botocore.response
-----------------

.. autoclass:: botocore.response.StreamingBody
   :members:

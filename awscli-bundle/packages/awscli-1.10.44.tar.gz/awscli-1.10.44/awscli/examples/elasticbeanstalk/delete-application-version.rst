**To delete an application version**

The following command deletes an application version named ``22a0-stage-150819_182129`` for an application named ``my-app``::

  aws elasticbeanstalk delete-application-version --version-label 22a0-stage-150819_182129 --application-name my-app
